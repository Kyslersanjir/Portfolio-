// Open and close modal functionality
const contactBtn = document.querySelector('.contact-btn');
const modal = document.getElementById('contact-modal');
const closeModalBtn = document.querySelector('.close-modal');
const navLinks = document.querySelectorAll('.nav-link');
const sections = document.querySelectorAll('.section');

contactBtn.addEventListener('click', () => {
    modal.style.transform = 'translate(-50%, -50%) scale(1)';
    modal.style.opacity = '1';
});

closeModalBtn.addEventListener('click', () => {
    modal.style.transform = 'translate(-50%, -50%) scale(0)';
    modal.style.opacity = '0';
});

document.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.transform = 'translate(-50%, -50%) scale(0)';
        modal.style.opacity = '0';
    }
});

// Navigation functionality
navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
        e.preventDefault();
        const target = e.target.getAttribute('data-target');

        sections.forEach(section => {
            if (section.id === target) {
                section.classList.remove('hidden');
            } else {
                section.classList.add('hidden');
            }
        });
    });
});
